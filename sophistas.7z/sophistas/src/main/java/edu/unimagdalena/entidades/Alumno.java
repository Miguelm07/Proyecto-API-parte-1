package edu.unimagdalena.entidades;

import java.io.Serializable;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="alumnos")
public class Alumno implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name  = "nombre")
	private String nombre;
	@Column(name="responsables_alunmos",unique = true)
	private String responsables_alunmos;
	@Column(name="apellido1")
	private String apellido1;
	@Column(name="apellido2")
	private String apellido2;
	
	@Column(name="nif",nullable = false, unique = true)
	private String nif;
	
	@Column(name="telefono",nullable = false, unique = true)
	private String telefono;
	
	@Column(name="correo",nullable = false, unique = true)
	private String correo;
	

	
	@Column(name="repetidor")
	private Boolean repetidor;
	
	@Column(name="fecha_alta")
	@Temporal(TemporalType.DATE)
	private Date fecha_alta;
	
	@Column(name="fecha_baja")
	@Temporal(TemporalType.DATE)
	private Date fecha_baja;
	
	@Column(name="observaciones")
	private String observaciones;
	
	
	
	// manytoone de alumnos con cursos
	@ManyToOne
	@JoinColumn(name="cursos_id")
	private Curso cursos;
	

	
	
    // clase_alumno

	@ManyToMany(mappedBy="alumnos")
	private Set<Clase> clasesalumnos;

	
	
	
	
	public Alumno() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public Boolean getRepetidor() {
		return repetidor;
	}

	public void setRepetidor(Boolean repetidor) {
		this.repetidor = repetidor;
	}

	public Date getFecha_alta() {
		return fecha_alta;
	}

	public void setFecha_alta(Date fecha_alta) {
		this.fecha_alta = fecha_alta;
	}

	public Date getFecha_baja() {
		return fecha_baja;
	}

	public void setFecha_baja(Date fecha_baja) {
		this.fecha_baja = fecha_baja;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public Curso getCurso() {
		return cursos;
	}

	public void setCurso(Curso curso) {
		this.cursos = curso;
	}

	public String getResponsable_alunmo() {
		return responsables_alunmos;
	}

	public void setResponsable_alunmo(String responsable_alunmo) {
		this.responsables_alunmos = responsable_alunmo;
	}

	public Set<Clase> getClases_alumnos() {
		return clasesalumnos;
	}

	public void setClases_alumnos(Set<Clase> clases_alumnos) {
		this.clasesalumnos = clases_alumnos;
	}
	
	
	
	
	
	
	
	
	
	
}
