package edu.unimagdalena.entidades;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "clases")
public class Clase implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	// id de los profesor
	
	@ManyToOne
	@JoinColumn(name="profesores_id")
	private Profesor profesores;
	
	// id de la asignatura
	@ManyToOne
	@JoinColumn(name="asignaturas_id")
	private Asignatura asignaturas; 
	
	
	// clase_horasemanal
	@ManyToMany
	@JoinTable(name="clases_horasemanales",
	joinColumns = @JoinColumn(name="clase_id",referencedColumnName ="id" ),
	inverseJoinColumns=@JoinColumn(name="horasemanal_id",referencedColumnName = "id"))
    private Set<Hora_semanal> horas_semanales;
	
	
	// clase_alumno
	@ManyToMany
	@JoinTable(name="clases_alumnos",
	joinColumns = @JoinColumn(name="clase_id",referencedColumnName ="id" ),
	inverseJoinColumns=@JoinColumn(name="alumno_id",referencedColumnName = "id"))
    private Set<Alumno> alumnos;

   
	
	
	public Clase() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Profesor getProfesores() {
		return profesores;
	}


	public void setProfesores(Profesor profesores) {
		this.profesores = profesores;
	}


	public Asignatura getAsignaturas() {
		return asignaturas;
	}


	public void setAsignaturas(Asignatura asignaturas) {
		this.asignaturas = asignaturas;
	}


	public Set<Hora_semanal> getHoras_semanales() {
		return horas_semanales;
	}


	
	
}
