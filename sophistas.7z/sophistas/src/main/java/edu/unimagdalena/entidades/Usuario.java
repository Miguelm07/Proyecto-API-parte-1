package edu.unimagdalena.entidades;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;



@Entity
@Table(name="usuarios")
public class Usuario implements Serializable {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="usuario",nullable = false)
	private String usuario;
	
	@Column(name="clave")
	private String clave;
	
	@Column(name="habilitado")
	private Integer habilitado;

	
	
	
	@ManyToMany(cascade = CascadeType.PERSIST)
    @JoinTable(name = "usuarios_roles", 
    joinColumns = @JoinColumn(name = "user_id", 
    referencedColumnName="id"), 
    inverseJoinColumns = @JoinColumn(name = "role_id",
    referencedColumnName="role_id"))
    private Set<Role> roles;
	
	
	
	public Usuario() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public Integer getHabilitado() {
		return habilitado;
	}

	public void setHabilitado(Integer habilitado) {
		this.habilitado = habilitado;
	}
	
	
	
	
}
