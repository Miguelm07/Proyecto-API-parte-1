package edu.unimagdalena.respositorios;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import edu.unimagdalena.entidades.Alumno;


@Repository
public interface AlumnoRepository extends JpaRepository<Alumno, Long> {

}
