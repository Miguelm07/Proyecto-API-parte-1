package edu.unimagdalena.respositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.unimagdalena.entidades.Asignatura;



@Repository
public interface AsiganturaRepository extends JpaRepository<Asignatura, Long> {

}
