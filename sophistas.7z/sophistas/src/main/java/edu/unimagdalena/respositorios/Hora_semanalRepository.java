package edu.unimagdalena.respositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.unimagdalena.entidades.Hora_semanal;



@Repository
public interface Hora_semanalRepository extends JpaRepository<Hora_semanal, Long> {

}
