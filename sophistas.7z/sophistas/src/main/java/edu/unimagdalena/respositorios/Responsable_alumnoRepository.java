package edu.unimagdalena.respositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.unimagdalena.entidades.Responsable_alumno;



@Repository
public interface Responsable_alumnoRepository extends JpaRepository<Responsable_alumno, Long> {

}
