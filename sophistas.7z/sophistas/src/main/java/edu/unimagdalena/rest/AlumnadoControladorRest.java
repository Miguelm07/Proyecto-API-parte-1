package edu.unimagdalena.rest;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.unimagdalena.entidades.Alumno;
import edu.unimagdalena.respositorios.AlumnoRepository;

@RestController
@RequestMapping("/api/v1")
public class AlumnadoControladorRest {
	@Autowired
	private AlumnoRepository alumRepository; 
	
	
	@GetMapping("/estudiantes")
	public List<Alumno> getEstudiantes(){
		return alumRepository.findAll();
	}
	@PostMapping("/estudiantes")
	public Alumno crearEstudiante(@RequestBody Alumno estudiante) {
		return alumRepository.save(estudiante);
	}
	@GetMapping("/estudiantes/{id}")
	public Alumno getEstudiante(@PathVariable Long id) {
		Optional<Alumno> estudiante = alumRepository.findById(id);
		if(!estudiante.isPresent()) {
			throw new EntityNotFoundException("No se encontro el estudiante con id "+id);
		}
				
		return estudiante.get();
	}

	@PutMapping("/estudiantes")
	public Alumno updateEstudiante(@RequestBody Alumno estudiante) {
		return alumRepository.save(estudiante);
	}
	@DeleteMapping("/estudiantes/{id}")
	public void eliminar(@PathVariable Long id) {
		Alumno est = alumRepository.getOne(id);
		alumRepository.delete(est);
	}

}
