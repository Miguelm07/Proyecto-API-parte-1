package edu.unimagdalena.rest;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import edu.unimagdalena.entidades.Clase;
import edu.unimagdalena.respositorios.ClaseRepository;

public class ClasesControladorRest {
	@Autowired
	private ClaseRepository clasRepository; 
	
	
	@GetMapping("/estudiantes")
	public List<Clase> getEstudiantes(){
		return clasRepository.findAll();
	}
	@PostMapping("/estudiantes")
	public Clase crearEstudiante(@RequestBody Clase estudiante) {
		return clasRepository.save(estudiante);
	}
	@GetMapping("/estudiantes/{id}")
	public Clase getEstudiante(@PathVariable Long id) {
		Optional<Clase> estudiante = clasRepository.findById(id);
		if(!estudiante.isPresent()) {
			throw new EntityNotFoundException("No se encontro el estudiante con id "+id);
		}
				
		return estudiante.get();
	}

	@PutMapping("/estudiantes")
	public Clase updateEstudiante(@RequestBody Clase estudiante) {
		return clasRepository.save(estudiante);
	}
	@DeleteMapping("/estudiantes/{id}")
	public void eliminar(@PathVariable Long id) {
		Clase est = clasRepository.getOne(id);
		clasRepository.delete(est);
	}
}
