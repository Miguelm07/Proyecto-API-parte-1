package edu.unimagdalena.rest;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import edu.unimagdalena.entidades.Asignatura;
import edu.unimagdalena.respositorios.AsiganturaRepository;

public class MantenimientoAsignaturaControladorRest {
	@Autowired
	private AsiganturaRepository clasRepository; 
	
	@GetMapping("/estudiantes")
	public List<Asignatura> getEstudiantes(){
		return clasRepository.findAll();
	}
	@PostMapping("/estudiantes")
	public Asignatura crearEstudiante(@RequestBody Asignatura estudiante) {
		return clasRepository.save(estudiante);
	}
	@GetMapping("/estudiantes/{id}")
	public Asignatura getEstudiante(@PathVariable Long id) {
		Optional<Asignatura> estudiante = clasRepository.findById(id);
		if(!estudiante.isPresent()) {
			throw new EntityNotFoundException("No se encontro el estudiante con id "+id);
		}
				
		return estudiante.get();
	}

	@PutMapping("/estudiantes")
	public Asignatura updateEstudiante(@RequestBody Asignatura estudiante) {
		return clasRepository.save(estudiante);
	}
	@DeleteMapping("/estudiantes/{id}")
	public void eliminar(@PathVariable Long id) {
		Asignatura est = clasRepository.getOne(id);
		clasRepository.delete(est);
	}
	
}
