package edu.unimagdalena.rest;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import edu.unimagdalena.entidades.Profesor;
import edu.unimagdalena.respositorios.ProfesorRepository;

public class ProfesoradoControladorRest {
	@Autowired
	private ProfesorRepository profRepository; 
	
	
	@GetMapping("/estudiantes")
	public List<Profesor> getEstudiantes(){
		return profRepository.findAll();
	}
	@PostMapping("/estudiantes")
	public Profesor crearEstudiante(@RequestBody Profesor estudiante) {
		return profRepository.save(estudiante);
	}
	@GetMapping("/estudiantes/{id}")
	public Profesor getEstudiante(@PathVariable Long id) {
		Optional<Profesor> estudiante = profRepository.findById(id);
		if(!estudiante.isPresent()) {
			throw new EntityNotFoundException("No se encontro el estudiante con id "+id);
		}
				
		return estudiante.get();
	}

	@PutMapping("/estudiantes")
	public Profesor updateEstudiante(@RequestBody Profesor estudiante) {
		return profRepository.save(estudiante);
	}
	@DeleteMapping("/estudiantes/{id}")
	public void eliminar(@PathVariable Long id) {
		Profesor est = profRepository.getOne(id);
		profRepository.delete(est);
	}
	
}
