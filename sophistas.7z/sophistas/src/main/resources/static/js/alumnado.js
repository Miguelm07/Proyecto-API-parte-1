$(document).ready(function(){
	$(".dropdown-trigger").dropdown({hover: true});
	$('.modal').modal();
	$('.modal-trigger').modal();
	$('select').formSelect();
	$('.datepicker').datepicker();
	//$('.modal-trigger2').modal();
	
	$('#crear').click(function(){
		//almacenar();
		ajaxPost();
		Swal.fire({
			  title: 'Informacion',
			  text: 'El alumno ha sido añadido',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#crear2').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'Los datos personales del alumno se han modificado',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#eliminar').click(function(e){
		var form = this;
		e.preventDefault();
		swal({
			  title: "¿Esta seguro de que desea dar de baja el alumno?",
			  icon: "warning",
			  buttons: true,
			  dangerMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
			    swal("El alumno ha sido dadod e baja", {
			      icon: "success",
			    });
			  } else {
			    //swal("Your imaginary file is safe!");
			  }
			});
	})

});



function almacenar() {
	
	alert("si funciona");

	// SUBMIT FORM
	$("#bookForm").submit(function(event) {
		// Prevent the form from submitting via the browser.
		event.preventDefault();
		ajaxPost();
	});

	function ajaxPost() {
		alert("si funciona 2");

		// PREPARE FORM DATA
		var formData = {
			bookId : $("#bookId").val(),
			bookName : $("#bookName").val(),
			author : $("#author").val()
		}

		// DO POST
		$.ajax({
			type : "POST",
			contentType : "application/json",
			url : "saveBook",
			data : JSON.stringify(formData),
			dataType : 'json',
			success : function(result) {
				if (result.status == "success") {
					$("#postResultDiv").html(
							"" + result.data.bookName
									+ "Post Successfully! <br>"
									+ "---> Congrats !!" + "</p>");
				} else {
					$("#postResultDiv").html("<strong>Error</strong>");
				}
				console.log(result);
			},
			error : function(e) {
				alert("Error!")
				console.log("ERROR: ", e);
			}
		});

	}

}

function ajaxPost() {
	alert("si funciona 2");

	// PREPARE FORM DATA
	var formData = {
		apellido1 : $("#bookId").val(),
		apellido2 : $("#bookName").val(),
		correo : "a",
		cursos_id : "a",
		fecha_alta : "2019-10-22",
		fecha_baja : "2019-10-22",
		nif : "a",
		nombre : "a",
		observaciones : "a",
		repetidor : true,
		responsables_alumnos : "a",
		telefono : "a",
		author : "a",
		author : "a"
	}

	// DO POST
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : "/api/v1/estudiantes",
		data : JSON.stringify(formData),
		dataType : 'json',
		success : function(result) {
			if (result.status == "success") {
				$("#postResultDiv").html(
						"" + result.data.bookName
								+ "Post Successfully! <br>"
								+ "---> Congrats !!" + "</p>");
			} else {
				$("#postResultDiv").html("<strong>Error</strong>");
			}
			console.log(result);
		},
		error : function(e) {
			alert("Error!")
			console.log("ERROR: ", e);
		}
	});

}