$(document).ready(function(){
	
	var ctx = document.getElementById('myChart').getContext('2d');
	var chart = new Chart(ctx, {
	    // The type of chart we want to create
	    type: 'doughnut',

	    // The data for our dataset
	    data: {
	    	labels: ['bachillerato', 'primaria', 'secundaria'],
	        datasets: [{
	            label: 'My First dataset',
	            backgroundColor: [
	            	'rgba(87, 212, 78, 1)',
	            	'rgba(255, 206, 86, 1)',
	            	'rgba(255, 99, 132, 1)'
	            ],
	            borderColor: [
	            	'rgba(87, 212, 78, 1)',
	                'rgba(255, 206, 86, 1)',
	                'rgba(255, 99, 132, 1)'
	            ],
	            data: [20, 10, 30],
	        }]
	    },

	    // Configuration options go here
	    options: {}
	});
	
	var ctx = document.getElementById('myChart2').getContext('2d');
	var chart = new Chart(ctx, {
	    // The type of chart we want to create
	    type: 'bar',

	    // The data for our dataset
	    data: {
	    	labels: ['bachillerato', 'primaria', 'secundaria'],
	        datasets: [{
	            label: 'My First dataset',
	            backgroundColor: [
	            	'rgba(87, 212, 78, 1)',
	            	'rgba(255, 206, 86, 1)',
	            	'rgba(255, 99, 132, 1)'
	            ],
	            borderColor: [
	            	'rgba(87, 212, 78, 1)',
	                'rgba(255, 206, 86, 1)',
	                'rgba(255, 99, 132, 1)'
	            ],
	            data: [20, 10, 30],
	        }]
	    },

	    // Configuration options go here
	    options: {}
	});
	
	$(".dropdown-trigger").dropdown({hover: true});
  

});